# AI-Powered Loan Eligibility and Risk Assessment System
## AI for Finance – CIA-2 Project Report

**Project type:** AI-powered financial decision-support prototype  
**Technology:** Python, Streamlit, Pandas, Scikit-learn, Random Forest  
**Student name:** ____________________  
**Register number:** ____________________  
**Class / Section:** ____________________  
**Institution:** ____________________

---

## 1. Abstract
This project demonstrates an AI-assisted loan eligibility and risk assessment application. A user enters an applicant's age, employment type, monthly income, existing monthly debt payments, credit score, employment duration, previous defaults, requested loan amount and repayment term. A supervised Random Forest classifier trained on synthetic labelled examples estimates whether the applicant is likely to be eligible. The application also calculates an illustrative monthly EMI and the ratio of total monthly obligations to income, displays an educational risk band, and provides suggestions. The system is intended for classroom learning and is not suitable for real lending decisions.

## 2. Problem Statement
Manual loan screening can involve reviewing several financial indicators. A simple educational decision-support tool can demonstrate how machine learning may identify patterns in applicant data and present consistent preliminary insights. The challenge is to combine applicant information, model predictions and understandable financial calculations in one interface.

## 3. Objectives
- Build a user-friendly loan assessment web application.
- Demonstrate supervised machine learning using a Random Forest classifier.
- Analyze income, debt, credit score, employment stability and requested loan details.
- Calculate estimated EMI and fixed-obligation-to-income ratio.
- Present a prediction, risk category and practical educational recommendations.
- Explain the benefits and limitations of AI in finance.

## 4. Tools and Technologies
- **Python:** application logic and model training.
- **Streamlit:** interactive web interface.
- **Pandas / NumPy:** dataset handling and calculations.
- **Scikit-learn:** preprocessing, model training and evaluation.
- **Joblib:** saving and loading the trained model.
- **VS Code:** development environment.

## 5. Dataset
The project includes `loan_applicants_sample.csv`, a generated dataset of 1,800 fictional applicant records. Features include age, employment type, monthly income, existing monthly EMI, credit score, employment years, loan amount, loan term and previous defaults. The target column is `loan_approved` (1 = likely eligible in the simulated dataset; 0 = not likely eligible). No real personal or banking records are used.

## 6. Methodology and AI Usage
1. Load the synthetic CSV dataset using Pandas.
2. Separate input features from the target label.
3. One-hot encode the categorical employment type; pass numerical columns through.
4. Split the records into training and test sets (80% / 20%).
5. Train a Random Forest classifier with 250 trees.
6. Evaluate the model on the held-out test set using accuracy, precision, recall, F1-score and a confusion matrix (printed by `train_model.py`).
7. Save the fitted pipeline with Joblib.
8. In the web app, collect new applicant information and use `predict` and `predict_proba` to generate a predicted class and model-estimated likelihood.

**Why Random Forest?** It combines predictions from multiple decision trees, can model non-linear relationships, and works with mixed numerical and encoded categorical features. It is a useful introductory classification algorithm.

## 7. Financial Calculations
The application estimates monthly EMI using an assumed monthly interest rate of 1.2% for demonstration. The EMI formula is:

EMI = P × r × (1+r)^n / ((1+r)^n − 1)

where P is principal, r is the assumed monthly interest rate and n is the number of monthly instalments.

The fixed-obligation-to-income ratio (FOIR) is calculated as:

FOIR = (existing monthly EMI + estimated new EMI) / monthly income

The interest rate is an illustrative assumption and is not a quote or offer from a lender.

## 8. Main Features
- Applicant information form.
- AI-generated likely-eligibility class and model probability.
- Estimated loan EMI.
- FOIR / monthly debt burden.
- Illustrative Low, Medium or High risk band using visible rule-based thresholds.
- Personalized educational recommendations based on the entered values.
- Sample dataset and reproducible model training.

## 9. Benefits and Practical Applications
- Demonstrates how AI can assist preliminary financial analysis.
- Combines multiple applicant indicators in one interface.
- Produces quick and consistent educational assessments.
- Helps students understand classification, model evaluation and financial ratios.
- Can serve as a starting point for studying responsible AI in lending.

## 10. Testing
Test the app with several fictional applicant profiles:
- Strong profile: higher income and credit score, low existing debt, no previous defaults.
- Moderate profile: average credit score and moderate debt.
- Weak profile: lower credit score, high debt burden or previous defaults.

Record the inputs and outputs in a test table during the demonstration. The model result is learned from synthetic data, so it may not always match a simple expectation.

## 11. Limitations and Responsible AI
This is a prototype, not a real credit underwriting system. Its dataset and labels are synthetic, its model probability is not a calibrated probability of repayment, and its risk band is a simple educational heuristic. A real system would require verified and lawfully obtained data, privacy safeguards, security, robust validation, bias and fairness testing, explainability, applicable regulatory review and human oversight. It must not make real loan approval or rejection decisions.

## 12. Conclusion
The project successfully demonstrates a complete educational workflow for an AI-assisted loan eligibility application: data preparation, model training, prediction, financial calculations and a web interface. It illustrates how AI can support financial analysis while highlighting the importance of data quality, fairness, transparency and human responsibility.

## 13. References
- Scikit-learn documentation: https://scikit-learn.org/
- Streamlit documentation: https://docs.streamlit.io/
- Pandas documentation: https://pandas.pydata.org/docs/
- Python documentation: https://docs.python.org/3/

