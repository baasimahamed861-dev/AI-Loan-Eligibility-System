# AI-Powered Loan Eligibility and Risk Assessment System

A classroom demonstration project for AI for Finance CIA-2.

## Features
- Applicant form for income, debts, credit score, employment and loan details
- Random Forest machine-learning eligibility classifier
- Estimated EMI and fixed-obligation-to-income (FOIR) calculation
- Illustrative Low / Medium / High risk heuristic
- Personalized educational recommendations
- Synthetic sample dataset and reproducible training script

## Requirements
- Python 3.10 or newer
- VS Code (recommended)

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `AI_Loan_Eligibility_Project` folder in VS Code.
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   ```powershell
   py -m venv .venv
   ```
5. Activate it:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, use Command Prompt terminal and run:
   ```cmd
   .venv\Scripts\activate.bat
   ```
6. Install packages:
   ```powershell
   py -m pip install -r requirements.txt
   ```
7. Train the model:
   ```powershell
   py train_model.py
   ```
   This creates `loan_model.joblib`.
8. Start the app:
   ```powershell
   py -m streamlit run app.py
   ```
9. A browser tab should open. Enter sample values in the sidebar and click **Analyze loan application**.

## Project files
- `app.py` — Streamlit user interface and assessment flow
- `train_model.py` — data preprocessing, model training and evaluation
- `loan_applicants_sample.csv` — synthetic training data
- `requirements.txt` — Python dependencies
- `PROJECT_REPORT.md` — report content
- `PRESENTATION_OUTLINE.md` — slide-by-slide presentation content

## AI explanation
The project uses a supervised machine-learning pipeline. A Random Forest classifier learns patterns from labelled synthetic applicant records. Categorical employment type is one-hot encoded; numerical fields are passed through. The model predicts the probability of the `loan_approved` class for a new applicant.

## Important limitations
- All training records are synthetic, not real customer or bank data.
- The label is simulated for teaching and does not represent a lender's actual underwriting policy.
- The risk band is a separate transparent heuristic, not a calibrated probability of default.
- The output must not be used to approve or reject real loans.
- Real deployment would require lawful and verified data, consent, security, explainability, bias/fairness testing, validation, regulatory review and human oversight.
