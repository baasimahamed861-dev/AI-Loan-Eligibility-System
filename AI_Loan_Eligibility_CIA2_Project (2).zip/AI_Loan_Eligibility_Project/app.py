"""
AI-Based Loan Eligibility & Risk Assessment
Run after training: streamlit run app.py
Educational prototype only. Not for real lending decisions.
"""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "loan_model.joblib"

st.set_page_config(page_title="AI Loan Risk Assessment", page_icon="🏦", layout="wide")

st.markdown("""
<style>
.main {background: #f7f9fc;}
[data-testid="stMetric"] {background: white; padding: 16px; border-radius: 12px; border: 1px solid #e6eaf0;}
div.stButton > button {border-radius: 9px; font-weight: 600;}
</style>
""", unsafe_allow_html=True)

st.title("🏦 AI-Powered Loan Eligibility & Risk Assessment")
st.caption("CIA-2 | Artificial Intelligence for Finance | Educational prototype")

if not MODEL_PATH.exists():
    st.error("The trained model was not found. In the project folder, run: python train_model.py")
    st.stop()

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

model = load_model()

with st.sidebar:
    st.header("Applicant information")
    name = st.text_input("Applicant name", "Sample Applicant")
    age = st.slider("Age", 21, 65, 29)
    employment_type = st.selectbox("Employment type", ["Salaried", "Self-employed"])
    employment_years = st.slider("Years in current employment/business", 0.0, 35.0, 3.0, 0.5)
    monthly_income = st.number_input("Monthly income (₹)", min_value=5000, max_value=1000000, value=60000, step=1000)
    existing_emi = st.number_input("Existing monthly EMI/debt payments (₹)", min_value=0, max_value=500000, value=8000, step=500)
    credit_score = st.slider("Credit score (illustrative)", 300, 900, 720)
    previous_defaults = st.selectbox("Previous loan defaults", [0, 1, 2, 3], index=0)
    loan_amount = st.number_input("Requested loan amount (₹)", min_value=10000, max_value=10000000, value=500000, step=10000)
    loan_term_months = st.selectbox("Loan term", [12, 24, 36, 48, 60, 72, 84], index=4)
    analyze = st.button("Analyze loan application", type="primary", use_container_width=True)

st.info("Enter sample applicant details in the sidebar, then select **Analyze loan application**.")

if analyze:
    applicant = pd.DataFrame([{
        "age": age,
        "employment_type": employment_type,
        "monthly_income": monthly_income,
        "existing_monthly_emi": existing_emi,
        "credit_score": credit_score,
        "employment_years": employment_years,
        "loan_amount": loan_amount,
        "loan_term_months": loan_term_months,
        "previous_defaults": previous_defaults,
    }])

    monthly_rate = 0.012  # illustrative assumed monthly interest rate (1.2%)
    if monthly_rate == 0:
        estimated_emi = loan_amount / loan_term_months
    else:
        factor = (1 + monthly_rate) ** loan_term_months
        estimated_emi = loan_amount * monthly_rate * factor / (factor - 1)

    total_monthly_obligation = existing_emi + estimated_emi
    foir = total_monthly_obligation / monthly_income if monthly_income else 1.0
    probabilities = model.predict_proba(applicant)[0]
    eligible_probability = float(probabilities[1])
    prediction = int(model.predict(applicant)[0])

    # Risk label is a transparent educational heuristic, separate from model output.
    if foir <= 0.40 and credit_score >= 750 and previous_defaults == 0:
        risk = "Low"
    elif foir <= 0.60 and credit_score >= 650 and previous_defaults <= 1:
        risk = "Medium"
    else:
        risk = "High"

    st.divider()
    st.subheader(f"Assessment result for {name or 'Applicant'}")
    c1, c2, c3 = st.columns(3)
    c1.metric("AI eligibility likelihood", f"{eligible_probability:.1%}")
    c2.metric("Estimated monthly loan EMI", f"₹{estimated_emi:,.0f}")
    c3.metric("Total EMI / income (FOIR)", f"{foir:.1%}")

    left, right = st.columns([1, 1])
    with left:
        if prediction == 1:
            st.success("AI result: Likely eligible")
        else:
            st.warning("AI result: Further review / likely not eligible")
        st.write(f"**Illustrative risk category:** {risk} risk")
        st.progress(min(max(eligible_probability, 0.0), 1.0), text="Model-estimated likelihood")
    with right:
        st.markdown("**Financial summary**")
        st.write(f"- Monthly income: ₹{monthly_income:,.0f}")
        st.write(f"- Existing monthly EMI: ₹{existing_emi:,.0f}")
        st.write(f"- Estimated new EMI: ₹{estimated_emi:,.0f}")
        st.write(f"- Total monthly obligations: ₹{total_monthly_obligation:,.0f}")
        st.write(f"- Credit score entered: {credit_score}")

    recommendations = []
    if foir > 0.50:
        recommendations.append("Consider a smaller loan amount or longer tenure to reduce the estimated EMI burden.")
    if credit_score < 700:
        recommendations.append("Review credit reports and build a consistent repayment history before applying.")
    if previous_defaults > 0:
        recommendations.append("Resolve outstanding dues and document the circumstances of previous defaults.")
    if employment_years < 1:
        recommendations.append("A longer, stable employment or business history may strengthen an application.")
    if not recommendations:
        recommendations.append("Maintain timely repayments and keep total monthly debt obligations manageable.")

    st.markdown("### Personalized educational recommendations")
    for item in recommendations:
        st.write("• " + item)

    st.caption("Important: Prediction is generated by a Random Forest model trained on synthetic classroom data. It is not a bank approval, credit score, financial advice, or a reliable real-world lending decision. Real lenders use verified records, jurisdiction-specific rules, fairness checks, and human review.")
else:
    st.subheader("How the prototype works")
    a, b, c = st.columns(3)
    a.markdown("### 1. Input\nApplicant income, debt, credit score, employment and loan details.")
    b.markdown("### 2. AI analysis\nA trained Random Forest classifier estimates the likely eligibility class.")
    c.markdown("### 3. Insights\nThe app shows probability, estimated EMI, debt burden and educational suggestions.")

st.divider()
st.caption("Built for AI for Finance CIA-2 | Sample data only | No personal financial data is stored.")
