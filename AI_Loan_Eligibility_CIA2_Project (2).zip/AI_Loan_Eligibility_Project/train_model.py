"""
Train the educational loan eligibility model.
Run: python train_model.py
The dataset is synthetic and the model is for classroom demonstration only.
"""
from pathlib import Path
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "loan_applicants_sample.csv"
MODEL_PATH = ROOT / "loan_model.joblib"

df = pd.read_csv(DATA_PATH)
X = df.drop(columns=["loan_approved"])
y = df["loan_approved"]

numeric_features = [
    "age", "monthly_income", "existing_monthly_emi", "credit_score",
    "employment_years", "loan_amount", "loan_term_months", "previous_defaults"
]
categorical_features = ["employment_type"]

preprocessor = ColumnTransformer(
    transformers=[
        ("numeric", "passthrough", numeric_features),
        ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical_features),
    ]
)

model = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(
        n_estimators=250, max_depth=9, min_samples_leaf=4,
        class_weight="balanced", random_state=42
    )),
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
model.fit(X_train, y_train)
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

joblib.dump(model, MODEL_PATH)
print("Model trained and saved to:", MODEL_PATH.name)
print(f"Hold-out accuracy: {accuracy:.3f}")
print("\nClassification report:")
print(classification_report(y_test, predictions, target_names=["Not likely eligible", "Likely eligible"]))
print("Confusion matrix:")
print(confusion_matrix(y_test, predictions))
print("\nNote: This is synthetic educational data, not a real lending model.")
