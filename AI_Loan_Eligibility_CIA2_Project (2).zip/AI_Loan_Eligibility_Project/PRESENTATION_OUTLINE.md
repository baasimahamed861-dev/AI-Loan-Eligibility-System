# Presentation Outline – AI-Powered Loan Eligibility and Risk Assessment

## Slide 1 – Title
AI-Powered Loan Eligibility and Risk Assessment System  
AI for Finance – CIA-2  
Student name, register number, class

## Slide 2 – Real-World Problem
- Loan assessment requires reviewing income, debt, credit history and employment.
- Reviewing many factors manually can be time-consuming.
- AI can demonstrate how patterns in historical labelled data may support preliminary analysis.

## Slide 3 – Project Objectives
- Build an interactive web application.
- Train a supervised ML classifier.
- Estimate EMI and debt burden.
- Display eligibility likelihood, risk band and recommendations.

## Slide 4 – Technology Stack
Python | Streamlit | Pandas | NumPy | Scikit-learn | Random Forest | Joblib | VS Code

## Slide 5 – How the AI Works
1. Use 1,800 synthetic applicant examples.
2. Encode employment type and prepare numerical features.
3. Split data into 80% training and 20% testing.
4. Train a Random Forest classifier.
5. Predict likely eligibility for a new applicant.

## Slide 6 – Application Features
- Applicant information form
- AI prediction and probability
- Estimated monthly EMI
- FOIR calculation
- Illustrative risk category
- Personalized educational suggestions

## Slide 7 – Live Demonstration
Open the Streamlit app, enter a fictional applicant profile, click Analyze loan application, and explain the displayed prediction and financial summary.

## Slide 8 – Benefits and Applications
- Fast educational assessment
- Consistent presentation of multiple indicators
- Helps explain machine learning in finance
- Can be a learning prototype for responsible decision support

## Slide 9 – Limitations and Responsible AI
- Synthetic data only
- Not a real bank model or credit decision
- Model probability is not a guaranteed repayment probability
- Real deployment needs privacy, fairness testing, explainability, regulation and human review

## Slide 10 – Conclusion
The project demonstrates how a supervised ML model can be integrated into a finance web app, while emphasizing that AI should support—not replace—responsible human decisions.

## Questions
Thank you. Any questions?
